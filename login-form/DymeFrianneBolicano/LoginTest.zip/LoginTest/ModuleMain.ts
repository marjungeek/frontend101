import { MylogForm } from "./Form";
import { DT } from "./MyInterface";

const obj1 = new MylogForm({
    postURL: 'https://22pnpc80ni.execute-api.ap-southeast-1.amazonaws.com/dev/login'
});

(()=> {
    
    obj1.userName.addEventListener('blur', (event:any)=> {
      event.preventDefault();
            
        const user = event.target.value;
    
        if (user !== '') {
          console.log('valid name');
          obj1.userName.setAttribute('class','form-control is-valid');
        } else {
            console.log('invalid name');
            obj1.userName.setAttribute('class','form-control is-invalid');
            }
    });
    
    obj1.password.addEventListener('blur', (event):void =>{
      event.preventDefault();
            
      const passwd = (<HTMLInputElement>event.target).value;
    
      if (passwd !== '') {
        console.log('valid password');
        obj1.password.setAttribute('class','form-control is-valid');
      } else {
          console.log('invalid password');
          obj1.password.setAttribute('class','form-control is-invalid');
        }
    });
      
    obj1.btnSubmit.addEventListener('click', async (event):Promise<any> => {
      event.preventDefault();
      console.log("SUbmit Clicked!");
     var ans=parseInt((<HTMLInputElement>obj1.ans).value);
      
      
      console.log(`ans: ${ans} total:${obj1.total}`);
      if(obj1.total==ans){

        let username = (<HTMLInputElement>obj1.userName).value;
        let password = (<HTMLInputElement>obj1.password).value;
       
        let data:DT = {
            username:username,
            password:password
        }
        console.log('UserName: ',username);
        console.log('password: ',password);

        var response:any = await obj1.postRequest(obj1.postURL, data);
        
        console.log(response);
        if(response.statusCode==200){
            console.log(response);
            obj1.userName.setAttribute('class','form-control is-valid');
            obj1.password.setAttribute('class','form-control is-valid');
            alert("Success!");
        }else{
            console.log(response);
            obj1.userName.setAttribute('class','form-control is-invalid');
            obj1.password.setAttribute('class','form-control is-invalid');
            alert("Fail!, invalid Credentials");
        }
        //console.log(response.statusCode);
      }
      else{
        alert('Wrong Capacha!');
        obj1.myRandom();
      }
        return response;
    });

    obj1.checkbox.addEventListener('click', ()=> {
      console.log('Check box triggered');
      obj1.myCheck();
    });

    // obj1.clear.addEventListener('click', ()=> {
    //   console.log('reloading...');
    //   location.reload();
    // });

})();