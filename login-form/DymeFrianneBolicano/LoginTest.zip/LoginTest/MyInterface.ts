export interface DT {
    username:string,password:string
}

